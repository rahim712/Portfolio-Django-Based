
from django.shortcuts import render
from .models import Skill

def skills_view(request):
    skills_data = Skill.objects.all()
    return render(request, 'skills/skills.html', {'skills': skills_data})

