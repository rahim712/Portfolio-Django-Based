from django.contrib import admin
from .models import Skill

admin.site.register(Skill)
