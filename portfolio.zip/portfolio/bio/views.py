from django.shortcuts import render
from .models import Bio

def bio_view(request):
    bio_data = Bio.objects.all()
    return render(request, 'bio/bio.html', {'bio': bio_data})
