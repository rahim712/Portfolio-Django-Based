
from django.shortcuts import render
from .models import Experience

def experience_view(request):
    experience_data = Experience.objects.all()
    return render(request, 'experience/experience.html', {'experience': experience_data})
