from django.shortcuts import render
from .models import Education

def education_view(request):
    education_data = Education.objects.all()
    return render(request, 'education/education.html', {'education': education_data})
