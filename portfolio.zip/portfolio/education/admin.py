from django.contrib import admin
from .models import Education

admin.site.register(Education)
