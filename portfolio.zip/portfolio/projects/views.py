# projects/views.py
from django.shortcuts import render
from .models import Project

def projects_view(request):
    projects_data = Project.objects.all()
    return render(request, 'projects/projects.html', {'projects': projects_data})
